<?php $__env->startSection('title', 'add device'); ?>

<?php $__env->startSection('css'); ?>
<!-- You can add custom CSS for this specific page here -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    
    <div class="row">
        <div class="col-md-6 grid-margin transparent mx-auto">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Add Device </h4>

                    <form class="forms-sample"action="<?php echo e(route('device_list_store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="">Location Name</label>
                            <input type="text" class="form-control" id="location_name" name="location_name" placeholder="Enter Location Name">
                        </div>
                        <div class="form-group">
                            <label for="">Street Name</label>
                            <input type="text" class="form-control" id="street_name" name="street_name" placeholder="Enter Street Name">
                        </div>
                        <div class="form-group">
                            <label for="">Camera Type</label>
                            <input type="text" class="form-control" id="camera_type" name="camera_type" placeholder="Enter Camera Type">
                        </div>
                        <div class="form-group">
                            <label for="">MAC ID</label>
                            <input type="text" class="form-control" id="mac_id" name="mac_id" placeholder="Enter MAC ID">
                        </div>
                        <div class="form-group">
                            <label for="">Installation Date</label>
                            <input type="date" class="form-control" id="installation_date" name="installation_date">
                        </div>
                        <div class="form-group">
                            <label for="">Expire Date</label>
                            <input type="date" class="form-control" id="expire_date" name="expire_date">
                        </div>
                        <button type="submit" class="btn btn-primary mr-2">Submit</button>
                        <button class="btn btn-light">Cancel</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Odisha-ITMS\resources\views/device/create_new.blade.php ENDPATH**/ ?>